package model;

public class EmpInovacao extends Empresa {


    @Override
    public void imprime() {
        System.out.println("Tratando Empresa Inovacao");
    }
}
