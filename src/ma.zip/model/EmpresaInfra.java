package model;

public class EmpresaInfra extends Empresa {


    @Override
    public void imprime() {
        System.out.println("Tratando Empresa Infra");
    }
}
